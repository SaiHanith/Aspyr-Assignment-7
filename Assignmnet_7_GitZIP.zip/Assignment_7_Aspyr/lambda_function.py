import pg8000
import boto3
import csv
from io import StringIO

# RDS PostgreSQL details
rds_host = 'mydbfinal.cvmqq2082taq.ap-south-1.rds.amazonaws.com'
rds_db = 'postgres'  # The database where your tables are located
rds_user = 'hanith'
rds_password = 'Hanith2004'
rds_port = 5432    

# SES email details
SES_REGION = 'ap-south-1'  # Mumbai (change if necessary)
SENDER = 'martha.saihanith@gmail.com'
RECIPIENT = 'martha.saichinnu@gmail.com'

def lambda_handler(event, context):
    cur = None
    conn = None
    try:
        # Connect to PostgreSQL using pg8000
        conn = pg8000.connect(
            host=rds_host,
            database=rds_db,
            user=rds_user,
            password=rds_password,
            port=rds_port
        )
        cur = conn.cursor()

        # Fetch data from OPT_Party table
        cur.execute("SELECT * FROM OPT_Party;")
        party_records = cur.fetchall()

        # Create CSV in-memory
        output = StringIO()
        csv_writer = csv.writer(output)
        csv_writer.writerow(['PTY_ID', 'PTY_FirstName', 'PTY_LastName', 'PTY_Phone', 'PTY_SSN'])

        for row in party_records:
            csv_writer.writerow(row)

        output.seek(0)
        csv_content = output.getvalue()

        # Send email with SES
        ses_client = boto3.client('ses', region_name=SES_REGION)

        raw_message = (
            f"From: {SENDER}\n"
            f"To: {RECIPIENT}\n"
            f"Subject: Party Records\n"
            "MIME-Version: 1.0\n"
            "Content-Type: multipart/mixed; boundary=\"NextPart\"\n\n"
            "--NextPart\n"
            "Content-Type: text/plain; charset=UTF-8\n\n"
            "Please find attached CSV file with party records.\n\n"
            "--NextPart\n"
            "Content-Type: text/csv; name=\"party_records.csv\"\n"
            "Content-Disposition: attachment; filename=\"party_records.csv\"\n\n"
            f"{csv_content}\n"
            "--NextPart--"
        )

        # Send the email using SES
        response = ses_client.send_raw_email(
            Source=SENDER,
            Destinations=[RECIPIENT],
            RawMessage={'Data': raw_message}
        )

        # Close the database connection
        return {
            'statusCode': 200,
            'body': 'Email sent with CSV attachment!'
        }

    except Exception as e:
        # Handle errors and close the connection
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': f"Error occurred: {str(e)}"
        }

    finally:
        # Ensure proper cleanup of connection and cursor
        if cur:
            cur.close()
        if conn:
            conn.close()

